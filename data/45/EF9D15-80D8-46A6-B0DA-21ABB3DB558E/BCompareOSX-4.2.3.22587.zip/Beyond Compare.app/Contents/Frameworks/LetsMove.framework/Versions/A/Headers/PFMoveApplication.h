//
//  PFMoveApplication.h, version 1.21
//  LetsMove
//
//  Created by Andy Kim at Potion Factory LLC on 9/17/09
//
//  The contents of this file are dedicated to the public domain.

#ifdef __cplusplus
extern "C" {
#endif

void PFMoveToApplicationsFolderIfNecessary(void);

#ifdef __cplusplus
}
#endif
